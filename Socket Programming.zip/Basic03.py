num_list = [1, 2, 3]

alpha_list = ['a', 'b', 'c']


for number in num_list:
    print(number)
    
    for letter in alpha_list:
        print(letter)
